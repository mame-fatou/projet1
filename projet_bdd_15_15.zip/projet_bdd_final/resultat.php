<!DOCTYPE html>
<html lang>
<HEAD>			
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
 <form method="get" action="resultat_ville.php" autocomplete="off"> 
 <form method="get" action="resultat_transport.php" autocomplete="off">
 
  <?php

$bdd= new PDO('mysql:host=localhost;dbname=projetgares;charset=utf8', 'root', 'root');
echo "Une fois sur ";
$variable= $_GET["ville"];
echo $variable;
echo ", vous avez choisi de voyager à la gare de ";
$var= $_GET["gare"];
echo $var;
echo".";
?>

<p class="comentaire"> Vous trouverez ici toutes les informations récoltées à partir de cette recherche. Bon voyage ! </p></br>

</head>
<style>


.mame {
  background-color: red ;
  overflow: auto;
}
.mame a {
  float: left;;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
  font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
}

</style>

  <?php 
  echo "A propos de ...  ";
  echo "<th><a href='resultat_ville.php?ville=".$variable."'>".$variable."</a></th>";
  echo " !";
  
  ?>
  <p></p>
  <?php
  echo "Correspondances possibles à partir de la gare de ";
   echo "<th><a href='resultat_transport.php?gare=".$var."'>".$var."</a></th>";
  ?>

<body>
     
			 <p>
			 <a href="ville.php">Faire une nouvelle recherche</a>
    </p>
	<p>
        <a href="profil.php">Mon Profil </a>
    </p>
	 
	<p>
        <a href="Accueil.php">Se déconnecter </a>
		     </p>


</body>
 </HTML>