	

<?php include 'bd.php' ?>
<!DOCTYPE html>
<html lang="en">

<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />


    <title>Page Villes </title>
	

</head>
<body>
   <h1 class="titre">Villes </h1>   

   
   
<p> Choisissez la ville qui vous intéresse afin de voir toutes les gares qui s'y trouvent et d'obtenir des informations qui vous interessent</p></br>   


  <form method="get" action="gare.php" autocomplete="off">


 <?php


$bdd= new PDO('mysql:host=localhost;dbname=projetgares;charset=utf8', 'root', 'root');
$rep = $bdd->query('select * from ville where region = "Grand-Est"');
echo "<table class= cMonTableau '>";
echo "<tr>";

echo "<th>Ville choisie : </th>";

echo "<th></th>";
echo "</tr>";
while ($line = $rep ->fetch()) {
echo "<tr>";

echo "<th><a href='gare.php?ville=".$line["nom"]."'>".$line["nom"]."</a></th>";
  

echo "</tr>";
}
echo "</table>";
$rep ->closeCursor();
?>
 
      <p><a href="profil.php">Mon Profil </a></p>
	  	<p><a href="ville.php">Retour à la page ville</a></p>
        <p><a href="accueil.php">retour à la page d'accueil </a></p>
  
</body>
</html>