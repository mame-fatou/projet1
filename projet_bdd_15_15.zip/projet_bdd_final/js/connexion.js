function zoomIn(zoom)
{
	document.getElementById(zoom).style.width = '500px';
	document.getElementById(zoom).style.height = '500px';

}
zoomIn('imgZoom1')

            
function zoomOut(zoom)
{

 document.getElementById(zoom).style.width = '200px';
 document.getElementById(zoom).style.height = '200px';
 
}
zoomOut('imgZoom1')

	