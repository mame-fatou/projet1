<!DOCTYPE html>
<html lang="en">
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
</head>
<body>

<H1>Désolé nous n'avons pas d'informations sur aucun des villes se trouvant dans cette region  </H1>

<p><a href="accueil.php">Faire une nouvelle recherche</a></p>
</body>

</html >