<?php
$bdd= new PDO('mysql:host=localhost;dbname=projetgares;charset=utf8', 'root', 'root');

$rep = $bdd->query('select POURCENTAGE from FREQUENTATION where NOM_GARE="Marne la Vallée Chessy" and ANNEE=2013') ;

while ($ligne = $rep ->fetch()) {
echo $ligne['POURCENTAGE'];
}


?>