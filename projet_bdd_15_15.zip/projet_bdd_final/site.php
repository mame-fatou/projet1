<!DOCTYPE html>
<html lang>
	
 
	<head>
		<title>Gar'ages</title>
	</head>
	
	<body>
		<br> Des informations impossibles a regrouper pour préparer votre prochain voyage ? Gar'ages ! </br>
		<br> <p><a href="profil.php">Mon profil </a></p> </br>
		<br> <p><a href="page_ville.php">page ville </a></p> </br>
		<br> <p><a href="page_gare.php">page gare </a></p> </br>
	</body>
</html>
